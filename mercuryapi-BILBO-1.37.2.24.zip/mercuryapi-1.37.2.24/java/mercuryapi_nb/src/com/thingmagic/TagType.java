/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.thingmagic;

/**
 *
 * @author pchinnapapannagari
 */
    // <summary>
    // Interface for TagType
    // </summary>
    public interface TagType
    {
        // <summary>
        // TagProtocol
        // </summary>
        TagProtocol getProtocol() ;
    }

